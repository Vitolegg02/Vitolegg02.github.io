***Outputs

#delimit ;

**Main Text;

*Table 2 (TWFE);
esttab ols1 ols2 twfe1 twfe2 twfe3 using "3. Tables/2_twfe.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles
prehead("& \multicolumn{5}{c}{Outcome Variable: Log Luminosity} \\") nostar s(mleft partyFE munFE timeFE sTrSeas errors N ymean r2_a, fmt(0 0 0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Cycle Controls" "Party FE" "Municipality FE" "Time FE" "Mun Trend \& Season" "Errors" "Observations" "Mean of Dep. Variable" "Adj. R-squared"))
keep(treated second_term term_length female win_margin _cons) order(treated second_term term_length female win_margin _cons);

*Table 3 (DiD);
esttab did1 did2 did3 did4 using "3. Tables/3_did_imputation.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles
prehead("& \multicolumn{4}{c}{Outcome Variable: Log Luminosity} \\") nostar s(TCont PCont munFE timeFE sTrSeas errors N ymean, fmt(0 0 0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Term Controls" "Politician Controls" "Municipality FE" "Time FE" "Mun Trend \& Season" "Errors" "Observations" "Mean of Dep. Variable")) rename(tau treated) keep(treated);

*Table 4 (Projects);
esttab project1 project2 project3 project4 using "3. Tables/4_projects.tex", replace se f booktabs b(3) se(3) alignment(S) label nomtitles prehead("& \multicolumn{4}{c}{Outcome Variable: Treatment Effect} \\") nostar;

*Table 5 (Wages);
esttab wages1 wages2 wages3 wages4 using "3. Tables/5_wages.tex", replace se f booktabs b(3) se(3) alignment(S) label nomtitles prehead("& \multicolumn{4}{c}{Outcome Variable: Treatment Effect} \\") nostar;

*Table 6 (Other Outcomes);
esttab fem_reg fem_did wm_reg wm_did ln_pop_reg ln_pop_did using "3. Tables/6_other_outcomes.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles
prehead("& \multicolumn{2}{c}{Female} & \multicolumn{2}{c}{Win Margin} & \multicolumn{2}{c}{Log Population} \\") nostar s(partyFE munFE timeFE errors N ymean r2_a, fmt(0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Party FE" "Municipality FE" "Time" "Errors" "Observations" "Mean of Dep. Variable" "Adj. R-squared")) rename(tau treated)
keep(treated last_half_year second_year female win_margin _cons) order(treated last_half_year second_year female win_margin _cons);


**Appendix

*Table A1 (TWFE non-truncated);
esttab a1_ols1 a1_ols2 a1_twfe1 a1_twfe2 a1_twfe3 using "3. Tables/a1_twfe_nt.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles prehead("& \multicolumn{5}{c}{Outcome Variable: Log Luminosity} \\") nostar s(mleft partyFE munFE timeFE sTrSeas errors N ymean r2_a, fmt(0 0 0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Cycle Controls" "Party FE" "Municipality FE" "Time FE" "Mun Trend \& Season" "Errors" "Observations" "Mean of Dep. Variable" "Adj. R-squared")) keep(treated second_term term_length female win_margin _cons) order(treated second_term term_length female win_margin _cons);

*Table A2 (TWFE dropped states);
esttab a2_ols1 a2_ols2 a2_twfe1 a2_twfe2 a2_twfe3 using "3. Tables/a2_twfe_ds.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles prehead("& \multicolumn{5}{c}{Outcome Variable: Log Luminosity} \\") nostar s(mleft partyFE munFE timeFE sTrSeas errors N ymean r2_a, fmt(0 0 0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Cycle Controls" "Party FE" "Municipality FE" "Time FE" "Mun Trend \& Season" "Errors" "Observations" "Mean of Dep. Variable" "Adj. R-squared")) keep(treated second_term term_length female win_margin _cons) order(treated second_term term_length female win_margin _cons);

*Table A3 (DiD non-truncated);
esttab a3_did1 a3_did2 a3_did3 a3_did4 using "3. Tables/a3_did_nt.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles prehead("& \multicolumn{4}{c}{Outcome Variable: Log Luminosity} \\") nostar s(TCont PCont munFE timeFE sTrSeas errors N ymean, fmt(0 0 0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Term Controls" "Politician Controls" "Municipality FE" "Time FE" "Mun Trend \& Season" "Errors" "Observations" "Mean of Dep. Variable")) rename(tau treated) keep(treated);

*Table A4 (DiD dropped states);
esttab a4_did1 a4_did2 a4_did3 a4_did4 using "3. Tables/a4_did_ds.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles prehead("& \multicolumn{4}{c}{Outcome Variable: Log Luminosity} \\") nostar s(TCont PCont munFE timeFE sTrSeas errors N ymean, fmt(0 0 0 0 0 0 0 3) layout("\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{c}{@}" "\multicolumn{1}{S[table-format=1.3]}{@}") label("Term Controls" "Politician Controls" "Municipality FE" "Time FE" "Mun Trend \& Season" "Errors" "Observations" "Mean of Dep. Variable")) rename(tau treated) keep(treated);

*Table A5 (other DiD types);
esttab a5_did1 a5_did2 a5_did3 a5_did4 using "3. Tables/a5_other_did.tex", replace se f booktabs b(3) se(3) alignment(S) varlabels(_cons Constant) label nomtitles prehead("& \multicolumn{4}{c}{Outcome Variable: Log Luminosity} \\") nostar;

*Table A6 (Heterotests);
esttab het_st het_wm het_female het_cartel using "3. Tables/a6_heterotests.tex", replace se f booktabs b(3) se(3) alignment(S) label nomtitles prehead("& \multicolumn{4}{c}{Outcome Variable: Log Luminosity} \\") nostar;

*eststo clear;