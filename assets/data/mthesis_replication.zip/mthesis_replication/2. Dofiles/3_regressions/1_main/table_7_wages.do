**Table 7 (Wages)
timer clear 1
timer on 1

eststo wages1: reg tau log_wages female win_margin cartel_presence log_pop log_gdp i.party_encoded, robust
eststo wages2: reg tau log_wages has_boni share_boni has_additions female win_margin cartel_presence log_pop log_gdp i.party_encoded, robust
eststo wages3: reg tau log_wages has_boni share_boni has_additions female win_margin cartel_presence log_pop log_gdp baseline_log_lum i.party_encoded, robust
eststo wages4: heckman tau log_wages has_boni share_boni has_additions female win_margin cartel_presence log_gdp baseline_log_lum i.party_encoded, select(observed_wage = log_pop) twostep

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table 7 (Wages)"

python script "send_email.py", args("`regname'" `h' `m' `s')