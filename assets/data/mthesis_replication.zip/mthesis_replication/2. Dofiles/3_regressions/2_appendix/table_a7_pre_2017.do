***Table A7 (DiD pre 2017)
timer clear 1
timer on 1

**DiD Imputation
eststo a4_did1: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & year<=2016, fe(municipality_encoded mdate months_left_encoded) cluster(municipality_encoded) maxit(5000) autosample

**DiD Imputation with Controls
eststo a4_did2: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & year<=2016, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) cluster(municipality_encoded) maxit(5000) autosample

**DiD Imputation with Trends
eststo a4_did3: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & num_pre_fe>15 & year<=2016, fe(municipality_encoded mdate months_left_encoded female party_encoded municipality_encoded#month) controls(win_margin) unitcontrols(t) cluster(municipality_encoded) maxit(20000) autosample

**DiD Imputation with Weights
eststo a4_did4: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & num_pre_fe>15 & year<=2016 [aw = population], fe(municipality_encoded mdate months_left_encoded female party_encoded municipality_encoded#month) controls(win_margin) unitcontrols(t) cluster(municipality_encoded) maxit(20000) autosample

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table A7"

python script "send_email.py", args("`regname'" `h' `m' `s')