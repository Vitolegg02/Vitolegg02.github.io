***Data Cleaning

*Merge Additions
merge m:1 municipality_pcode using "1. Data\cartels.dta", nogenerate
merge m:1 municipality_pcode using "1. Data\wages.dta", nogenerate

*Logs
gen log_lum = log(mean_luminosity)
gen log_pop = log(population)
gen log_wages = log(total)
gen log_boni = log(boni)

*Trunctuation Threshold
quietly summarize log_lum, detail
local p1 = r(p1)
local p99 = r(p99)
gen trunctuated = cond(log_lum<=`p99',cond(log_lum>=`p1',1,0),0)

*Trunctuated Outcome
gen log_lum_trunc = log_lum
quietly summarize log_lum, detail
replace log_lum_trunc = r(p1)  if log_lum < r(p1)
replace log_lum_trunc = r(p99) if log_lum > r(p99)

*Non-Random Missing Wages
gen observed_wage = 1
replace observed_wage = 0 if missing(log_wages)

*For Within-Term Cycles
egen months_left_encoded = group(months_to_election), label
gen last_half_year = cond(months_to_election>=1 & months_to_election<=6,1,0)
gen second_year = cond(months_to_election>=7 & months_to_election<=18,1,0)
gen first_years = cond(months_to_election>18,1,0)
gen elections_passed_t = months_to_election*elections_passed
gen last_half_year_t = months_to_election*last_half_year
gen second_year_t = (months_to_election-6)*second_year
gen first_years_t = (months_to_election-18)*first_years
gen half_year_post = elections_passed
gen half_year_1 = last_half_year
gen half_year_2 = second_year
replace half_year_2 = 0 if months_to_election>=13
gen half_year_3 = second_year
replace half_year_3 = 0 if months_to_election<13
gen half_year_4 = first_years
replace half_year_4 = 0 if months_to_election>=25
gen half_year_5 = first_years
replace half_year_5 = 0 if months_to_election<25

*Second Term and Term Length
gen second_term = 0
replace second_term = 1 if regexm(race_after,"Term-limited") & treated==1
replace second_term = 1 if regexm(race_after,"term-limited") & treated==1
gen term_length = next_election - last_election

gen reelected = 0
replace reelected = 1 if regexm(race_after,"Reelected") & treated==1
replace reelected = 1 if regexm(race_after,"reelected") & treated==1

*Dominant Party from Coalition
gen part_general = ""
replace part_general = "PRI"    if regexm(party,"pri")
replace part_general = "PAN"    if regexm(party,"pan")
replace part_general = "PRD"    if regexm(party,"prd")
replace part_general = "MORENA" if regexm(party,"morena")
replace part_general = "PVEM"   if regexm(party,"pvem")
replace part_general = "PT"     if regexm(party,"pt")
replace part_general = "MC"     if regexm(party,"mc")
replace part_general = "PNA"    if regexm(party,"pna")
replace part_general = "PES"    if regexm(party,"pes")
replace part_general = "INDEP"  if regexm(party,"indep")

*Above Median Win Margin
gen high_wm = 0
replace high_wm = 1 if win_margin>=0.125

*Encoding and Grouping
encode state_pcode, gen(state_encoded)
encode municipality_pcode, gen(municipality_encoded)
encode part_general, gen(party_encoded)
egen state_month = group(state_encoded year month)
egen state_year = group(state_encoded year)

*Time Setting
gen mdate = ym(year, month)
format mdate %tm
xtset municipality_encoded mdate

by municipality_encoded: egen first_treatment = min(cond(treated==1, mdate, .))
gen t = mdate - tm(2012m3)
by municipality_encoded: egen transition_term = min(cond(mdate==first_treatment, term_length, .))

gen time_since_treatment = mdate - first_treatment
gen ft_csdid = first_treatment
replace ft_csdid = 0 if missing(first_treatment)

bysort municipality_encoded: egen baseline_log_lum = mean(cond(mdate == 627, log_lum_trunc, .))

*Factorization for DID Multiple GT
quietly tabulate months_left_encoded, generate(m_left_)
quietly tabulate party_encoded, generate(party_)
forvalues s = 1/32 {
    gen state_trend_`s' = (state_encoded==`s')*t
}

*Regional GDP
gen regional_gdp = .
replace regional_gdp = 403105 if state_pcode == "MX01"
replace regional_gdp = 1195734 if state_pcode == "MX02"
replace regional_gdp = 233987 if state_pcode == "MX03"
replace regional_gdp = 504992 if state_pcode == "MX04"
replace regional_gdp = 1142896 if state_pcode == "MX05"
replace regional_gdp = 204887 if state_pcode == "MX06"
replace regional_gdp = 507299 if state_pcode == "MX07"
replace regional_gdp = 1203424 if state_pcode == "MX08"
replace regional_gdp = 4666490 if state_pcode == "MX09"
replace regional_gdp = 429302 if state_pcode == "MX10"
replace regional_gdp = 1418541 if state_pcode == "MX11"
replace regional_gdp = 409572 if state_pcode == "MX12"
replace regional_gdp = 549803 if state_pcode == "MX13"
replace regional_gdp = 2346791 if state_pcode == "MX14"
replace regional_gdp = 2851132 if state_pcode == "MX15"
replace regional_gdp = 871949 if state_pcode == "MX16"
replace regional_gdp = 333153 if state_pcode == "MX17"
replace regional_gdp = 211895 if state_pcode == "MX18"
replace regional_gdp = 2502859 if state_pcode == "MX19"
replace regional_gdp = 601530 if state_pcode == "MX20"
replace regional_gdp = 1109728 if state_pcode == "MX21"
replace regional_gdp = 743257 if state_pcode == "MX22"
replace regional_gdp = 474490 if state_pcode == "MX23"
replace regional_gdp = 729288 if state_pcode == "MX24"
replace regional_gdp = 670927 if state_pcode == "MX25"
replace regional_gdp = 1023471 if state_pcode == "MX26"
replace regional_gdp = 671372 if state_pcode == "MX27"
replace regional_gdp = 938597 if state_pcode == "MX28"
replace regional_gdp = 185848 if state_pcode == "MX29"
replace regional_gdp = 1362283 if state_pcode == "MX30"
replace regional_gdp = 514180 if state_pcode == "MX31"
replace regional_gdp = 318401 if state_pcode == "MX32"
gen log_gdp = log(regional_gdp)

*For Unitcontrols (Non-Corrupted Untreated Dates)
gen corrupted = 0
replace corrupted = 1 if trunctuated == 0
replace corrupted = 1 if missing(win_margin)
replace corrupted = 1 if missing(female)
replace corrupted = 1 if missing(party)
gen cor_unt = 0
replace cor_unt = 1 if corrupted==1 & treated==0
by municipality_encoded: egen num_cu = total(cor_unt)
by municipality_encoded: egen num_tr = total(treated)
gen num_unt = 166 - num_tr
gen num_pre_fe = num_unt-num_cu

*Variable Labels
la var treated "Reelection Introduced"
la var second_term "Second Term"
la var term_length "Term Length"
la var months_to_election "Months to Next Election"
la var months_left_encoded "Months to Next Election"
la var elections_passed "Elections Passed"
la var elections_passed_t "Trend Elections Passed"
la var last_half_year "Half Year Left"
la var last_half_year_t "Trend Half Year"
la var second_year "Second Year"
la var second_year_t "Trend Second Year"
la var first_years "Early Years"
la var first_years_t "Trend Early Years"
la var log_lum "Log Luminosity"
la var log_pop "Log Population"
la var win_margin "Win Margin"
la var female "Female"
la var cartel_presence "Cartel Presence"
la var log_gdp "Log GDP"
la var log_wages "Log Wages"
la var has_boni "Any Bonus Payments"
la var share_boni "Share of Bonus Payments"
la var has_additions "Any Additional Fixed Payments"