**Table 5 (Projects)
timer clear 1
timer on 1

*Baseline Regression
did_imputation log_lum_trunc municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) saveestimates(tau) maxit(20000) autosample nose

*Projection Regressions
eststo project1: reg tau female win_margin cartel_presence log_pop i.party_encoded, robust
eststo project2: reghdfe tau female win_margin, absorb(municipality_encoded mdate party_encoded) vce(cluster municipality_encoded)
eststo project3: reghdfe tau female win_margin second_term, absorb(municipality_encoded mdate party_encoded months_left_encoded time_since_treatment) vce(cluster municipality_encoded)
eststo project4: reghdfe tau female win_margin second_term if second_term==1|reelected==1, absorb(municipality_encoded mdate party_encoded months_left_encoded time_since_treatment) vce(cluster municipality_encoded)

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table 5 (Projects)"

python script "send_email.py", args("`regname'" `h' `m' `s')