**Figure 7 (Term Cycles)

*New Variables
gen doublemonths_left = round(months_to_election/2)
replace doublemonths_left = 24 if doublemonths_left>24

gen dml_str = string(doublemonths_left)
replace dml_str = "neg" + string(-doublemonths_left) if doublemonths_left<0

gen lead_first_treatment = first_treatment-36


*Estimation
timer clear 1
timer on 1

eststo pre_cycles: did_imputation log_lum municipality_encoded mdate lead_first_treatment if trunctuated==1 & treated==0 & state_encoded!=13 & state_encoded!=30, fe(municipality_encoded mdate months_left_encoded female) cluster(municipality_encoded) hetby(dml_str) maxit(10000) autosample

eststo term_cycles: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & state_encoded!=13 & state_encoded!=30, fe(municipality_encoded mdate months_left_encoded female) cluster(municipality_encoded) hetby(dml_str) maxit(10000) autosample

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Figure 7 (Cycles)"

python script "C:\Users\vpetukhov\Desktop\send_email.py", args("`regname'" `h' `m' `s')


*Estimates and Bounds Cycle
preserve
matrix b = e(b)
matrix V = e(V)
clear

svmat b, names(col)
gen id = 1
reshape long tau_, i(id) j(name) string
drop id

gen k = .
replace k = real(substr(name, 4, .)) if strpos(name, "neg")
replace k = -real(name) if missing(k)

matrix se = vecdiag(V)'
svmat se, names(col)
gen tau_cycle = tau_
gen se_cycle = sqrt(r1)

keep k tau_cycle se_cycle
sort k

save "C:\Users\vpetukhov\Desktop\Viktor Stata\4. Figures\7_1_cycle_estimates.dta", replace
restore

*Estimates and Bounds Pre Cycle
est restore pre_cycles
preserve
matrix b = e(b)
matrix V = e(V)
clear

svmat b, names(col)
gen id = 1
reshape long tau_, i(id) j(name) string
drop id

gen k = .
replace k = real(substr(name, 4, .)) if strpos(name, "neg")
replace k = -real(name) if missing(k)

matrix se = vecdiag(V)'
svmat se, names(col)
gen tau_pre_cycle = tau_
gen se_pre_cycle = sqrt(r1)

keep k tau_pre_cycle se_pre_cycle
sort k

save "C:\Users\vpetukhov\Desktop\Viktor Stata\4. Figures\7_2_pre_cycle_estimates.dta", replace
restore

*Graph
preserve
use "C:\Users\vpetukhov\Desktop\Viktor Stata\4. Figures\7_1_cycle_estimates.dta", replace
merge 1:1 k using "C:\Users\vpetukhov\Desktop\Viktor Stata\4. Figures\7_2_pre_cycle_estimates.dta"
keep if k<=15 & k >= -3

twoway (rarea ub_cycle lb_cycle k, color(navy%50)) (scatter tau_cycle k, mcolor(navy) msymbol(O)) (line tau_cycle k, lcolor(navy)) (rarea ub_pre_cycle lb_pre_cycle k, color(maroon%50)) (scatter tau_pre_cycle k, mcolor(maroon) msymbol(O)) (line tau_pre_cycle k, lcolor(maroon)), xline(0, lpattern(dash) lcolor(gs8)) yline(0, lcolor(gs8)) ytitle("Treatment effect") xtitle("") xlabel(-12 "2 Years Left" -6 "1 Year Left" 0 "Election") legend(off)

graph export "4. Figures/7_cycles.png", replace

timer clear 1
timer on 1

eststo cycles: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & state_encoded!=13 & state_encoded!=30 & num_pre_fe>15, fe(municipality_encoded mdate months_left_encoded) unitcontrols(t last_half_year_t second_year_t first_years_t) cluster(municipality_encoded) hetby(dml_str) maxit(20000) autosample

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Figure 7 (Cycles)"

python script "C:\Users\vpetukhov\Desktop\send_email.py", args("`regname'" `h' `m' `s')