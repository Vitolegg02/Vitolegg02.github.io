***Table A3 (DiD non-Truncated)

timer clear 1
timer on 1

**DiD Imputation
eststo a3_did1: did_imputation log_lum municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded) cluster(municipality_encoded) maxit(10000)
*did_imputation log_lum municipality_encoded mdate first_treatment, fe(municipality_encoded mdate elections_passed last_half_year second_year) controls(elections_passed_t last_half_year_t second_year_t first_years_t) cluster(municipality_encoded) maxit(300)
*did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate elections_passed last_half_year second_year) controls(elections_passed_t last_half_year_t second_year_t first_years_t) cluster(municipality_encoded) maxit(300)

**DiD with Controls
eststo a3_did2: did_imputation log_lum municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) cluster(municipality_encoded) maxit(10000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment, fe(municipality_encoded mdate elections_passed last_half_year second_year female party_encoded) controls(elections_passed_t last_half_year_t second_year_t first_years_t win_margin) cluster(municipality_encoded) maxit(300) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate elections_passed last_half_year second_year female party_encoded) controls(elections_passed_t last_half_year_t second_year_t first_years_t win_margin) cluster(municipality_encoded) maxit(300) autosample

**DiD with Trends
eststo a3_did3: did_imputation log_lum municipality_encoded mdate first_treatment if num_pre_fe>15, fe(municipality_encoded mdate months_left_encoded female party_encoded municipality_encoded#month) controls(win_margin) unitcontrols(t) cluster(municipality_encoded) maxit(20000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment, fe(municipality_encoded mdate elections_passed last_half_year second_year female party_encoded state_encoded#month) controls(elections_passed_t last_half_year_t second_year_t first_years_t win_margin state_trend_*) cluster(municipality_encoded) maxit(2000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate elections_passed last_half_year second_year female party_encoded state_encoded#month) controls(elections_passed_t last_half_year_t second_year_t first_years_t win_margin state_trend_*) cluster(municipality_encoded) maxit(2000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded state_encoded#month) controls(win_margin state_trend_*) cluster(municipality_encoded) maxit(5000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate months_left_encoded female party_encoded state_encoded#month) controls(win_margin state_trend_*) cluster(municipality_encoded) maxit(5000) autosample

**DiD with Weights
eststo a3_did4: did_imputation log_lum municipality_encoded mdate first_treatment if num_pre_fe>15 [aw = population], fe(municipality_encoded mdate months_left_encoded female party_encoded municipality_encoded#month) controls(win_margin) unitcontrols(t) cluster(municipality_encoded) maxit(20000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment [aw = population], fe(municipality_encoded mdate elections_passed last_half_year second_year female party_encoded state_encoded#month) controls(elections_passed_t last_half_year_t second_year_t first_years_t win_margin state_trend_*) cluster(municipality_encoded) maxit(2000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 [aw = population], fe(municipality_encoded mdate elections_passed last_half_year second_year female party_encoded state_encoded#month) controls(elections_passed_t last_half_year_t second_year_t first_years_t win_margin state_trend_*) cluster(municipality_encoded) maxit(2000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment [aw = population], fe(municipality_encoded mdate months_left_encoded female party_encoded state_encoded#month) controls(win_margin state_trend_*) cluster(municipality_encoded) maxit(5000) autosample
*did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 [aw = population], fe(municipality_encoded mdate months_left_encoded female party_encoded state_encoded#month) controls(win_margin state_trend_*) cluster(municipality_encoded) maxit(5000) autosample

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table A3"

python script "send_email.py", args("`regname'" `h' `m' `s')