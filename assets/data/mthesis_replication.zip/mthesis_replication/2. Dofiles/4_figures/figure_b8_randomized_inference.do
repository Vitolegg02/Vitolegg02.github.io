*Figure B8 (Randomized Inference)

timer clear 1
timer on 1

set seed 12345
local reps = 1000

*Actual Regression
did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate months_left_encoded) nose
scalar beta_actual = _b[tau]

*State-Level Treatment File
preserve
keep state_encoded first_treatment
duplicates drop
tempfile state_treatments
save `state_treatments'
restore

*File for Betas
tempname results
postfile `results' rep beta using ri_results.dta, replace

*Loop
forvalues r = 1/`reps' {
    di "Permutation `r' of `reps'"
	
    *Reshufle Treatment
    preserve
    use `state_treatments', clear
    gen u = runiform()
    sort u
    quietly gen placebo_treat = first_treatment
    keep placebo_treat
    gen shuffle_id = _n
    tempfile shuffled
    quietly save `shuffled'
    use `state_treatments', clear
    sort state_encoded
    gen shuffle_id = _n
    quietly merge 1:1 shuffle_id using `shuffled', nogen
    keep state_encoded placebo_treat
    tempfile placebo
    quietly save `placebo'
    restore

    capture drop placebo_treat
    quietly merge m:1 state_encoded using `placebo', nogen

	*Placebo Regression
    quietly did_imputation log_lum municipality_encoded mdate placebo_treat if trunctuated==1, fe(municipality_encoded mdate months_left_encoded) nose

    *Store Betas
    post `results' ///
        (`r') ///
        (_b[tau])

    drop placebo_treat
}

postclose `results'

preserve
use ri_results.dta, clear

*P-value
gen extreme = abs(beta) >= abs(beta_actual)
sum extreme
display "RI p-value = " r(mean)

*Histogram
histogram beta, normal xline(`=beta_actual', lcolor(red) lwidth(thick))
graph export "4. Figures/B8_randomized_inference.png", replace
restore

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Figure B8 (Randomized Inference)"

python script "send_email.py", args("`regname'" `h' `m' `s')