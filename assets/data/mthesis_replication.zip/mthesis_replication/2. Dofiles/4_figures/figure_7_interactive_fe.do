**Figure X (With Interactive Fixed Effects)
timer clear 1
timer on 1

preserve
fect log_lum if trunctuated==1, treat(treated) unit(municipality_encoded) time(mdate) cov(months_left_encoded) preperiod(-36) offperiod(72) se
graph export "4. Figures/7_interactive_fe.png", replace
restore

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Figure 7 (With Interactive Fixed Effects)"

python script "send_email.py", args("`regname'" `h' `m' `s')