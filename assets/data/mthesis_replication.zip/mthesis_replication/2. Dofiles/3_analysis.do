***Regressions

*Main Text
capture noisily do "2. Dofiles\3_regressions\1_main\table_2_twfe.do"
capture noisily do "2. Dofiles\3_regressions\1_main\table_3_did_imputation.do"
capture noisily do "2. Dofiles\3_regressions\1_main\table_4_cycles.do"
capture noisily do "2. Dofiles\3_regressions\1_main\table_5_projects.do"
capture noisily do "2. Dofiles\3_regressions\1_main\table_6_other_outcomes.do"
capture noisily do "2. Dofiles\3_regressions\1_main\table_7_wages.do"

*Appendix
capture noisily do "2. Dofiles\3_regressions\2_appendix\table_a1_twfe_nontrunc.do"
capture noisily do "2. Dofiles\3_regressions\2_appendix\table_a2_twfe_dropstates.do"
capture noisily do "2. Dofiles\3_regressions\2_appendix\table_a3_did_nontrunc.do"
capture noisily do "2. Dofiles\3_regressions\2_appendix\table_a4_did_dropstates.do"
capture noisily do "2. Dofiles\3_regressions\2_appendix\table_a5_other_did.do"
capture noisily do "2. Dofiles\3_regressions\2_appendix\table_a6_heterotests.do"