import smtplib
import sys
from email.message import EmailMessage

regression_name = sys.argv[1]
h = sys.argv[2]
m = sys.argv[3]
s = sys.argv[4]

msg = EmailMessage()
msg.set_content(f"Your calculation of {regression_name} has finished.\n"
    f"The total calculation took {h} hours {m} minutes and {s} seconds.")
msg["Subject"] = "Stata job done"
msg["From"] = "vpetukhov.technical@gmail.com"
msg["To"] = "vpetukhov@nes.ru"

server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
server.login("vpetukhov.technical@gmail.com", "udhh kvcc qwvi ibtx")
server.send_message(msg)
server.quit()