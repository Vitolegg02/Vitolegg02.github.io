***Table 3 (DiD Imputation)
timer clear 1
timer on 1

**DiD Imputation
eststo did1: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate months_left_encoded) cluster(municipality_encoded) maxit(5000)
quietly estadd local TCont "\text{Yes}", replace
quietly estadd local PCont "\text{No}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{No}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

**DiD Imputation with Controls
eststo did2: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) cluster(municipality_encoded) maxit(5000) autosample
quietly estadd local TCont "\text{Yes}", replace
quietly estadd local PCont "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{No}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

**DiD Imputation with Trends
eststo did3: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & num_pre_fe>15, fe(municipality_encoded mdate months_left_encoded female party_encoded municipality_encoded#month) controls(win_margin) unitcontrols(t) cluster(municipality_encoded) maxit(20000) autosample
quietly estadd local TCont "\text{Yes}", replace
quietly estadd local PCont "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{Yes}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

**DiD Imputation with Weights
eststo did4: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1 & num_pre_fe>15 [aw = population], fe(municipality_encoded mdate months_left_encoded female party_encoded municipality_encoded#month) controls(win_margin) unitcontrols(t) cluster(municipality_encoded) maxit(20000) autosample
quietly estadd local TCont "\text{Yes}", replace
quietly estadd local PCont "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{Yes}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table 3 (DiD Imputation)"

python script "send_email.py", args("`regname'" `h' `m' `s')