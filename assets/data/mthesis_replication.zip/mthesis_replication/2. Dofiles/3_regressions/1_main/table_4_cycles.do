**Table 4 (Term Cycles)

reghdfe tau half_year_post half_year_1 half_year_2 half_year_3 half_year_4 half_year_5 second_term, absorb(municipality_encoded mdate time_since_treatment) vce(cluster municipality_encoded)

lincom _cons
lincom _cons + half_year_4
lincom _cons + half_year_3
lincom _cons + half_year_2
lincom _cons + half_year_1
lincom _cons + half_year_post