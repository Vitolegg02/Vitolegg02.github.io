***Figures

capture noisily do "2. Dofiles\4_figures\figure_6_dynamic_effects.do"
capture noisily do "2. Dofiles\4_figures\figure_7_interactive_fe.do"
capture noisily do "2. Dofiles\4_figures\figure_b8_randomized_inference.do"