**Figure 6 (Dynamic Effects)
timer clear 1
timer on 1

eststo fig_did: did_imputation log_lum municipality_encoded mdate first_treatment if trunctuated==1, fe(municipality_encoded mdate months_left_encoded female) cluster(municipality_encoded) horizons(0/72) pretrends(36) autosample maxit(20000)

event_plot fig_did, alpha(0.01) ciplottype(rarea) graph_opt(xtitle("Years Relative to Treatment") xlabel(-36 "-3" -24 "-2" -12 "-1" 0 "0" 12 "1" 24 "2" 36 "3" 48 "4" 60 "5" 72 "6") xline(0, lcolor(gs2) lpattern(dash)) xline(36, lcolor(gs10) lpattern(dash)) yline(0, lcolor(gs10)) legend(off)) lag_opt(msymbol(O) color(navy) lcolor(navy)) lag_ci_opt(color(navy%40)) lead_opt(msymbol(O) color(maroon)) lead_ci_opt(color(maroon%40))

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Figure 6 (Dynamic Effects)"

estimates save "4. Figures/6_dynamic_effects.ster", replace
graph export "4. Figures/6_dynamic_effects.png", replace

python script "send_email.py", args("`regname'" `h' `m' `s')