***Table A2 (TWFE with Dropped States)

timer clear 1
timer on 1

**Simple OLS
eststo a2_ols1: reg log_lum treated if trunctuated==1 & state_encoded!=30 & state_encoded != 13 & state_encoded != 9, robust

**OLS with Control
eststo a2_ols2: reg log_lum treated i.months_left_encoded if trunctuated==1 & state_encoded!=30 & state_encoded != 13 & state_encoded != 9, robust

**TWFE
eststo a2_twfe1: reghdfe log_lum treated if trunctuated==1 & state_encoded!=30 & state_encoded != 13 & state_encoded != 9, absorb(mdate municipality_encoded months_left_encoded) vce(cluster municipality_encoded)

**TWFE with Controls
eststo a2_twfe2: reghdfe log_lum treated female win_margin second_term term_length if trunctuated==1 & state_encoded!=30 & state_encoded != 13 & state_encoded != 9, absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)

**TWFE with Trends
eststo a2_twfe3: reghdfe log_lum treated female win_margin second_term term_length municipality_encoded#c.mdate if trunctuated==1 & state_encoded!=30 & state_encoded != 13 & state_encoded != 9, absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table A2"

python script "send_email.py", args("`regname'" `h' `m' `s')