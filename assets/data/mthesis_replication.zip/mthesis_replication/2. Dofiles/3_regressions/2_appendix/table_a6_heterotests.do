**Table A1 (Heterotests)
timer clear 1
timer on 1

*Second Term
eststo het_st: did_imputation log_lum_trunc municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) hetby(second_term) maxit(20000) autosample
*Win Margin
eststo het_wm: did_imputation log_lum_trunc municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) hetby(high_wm) maxit(20000) autosample
*Female
eststo het_female: did_imputation log_lum_trunc municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) hetby(female) maxit(20000) autosample
*Cartel
eststo het_cartel: did_imputation log_lum_trunc municipality_encoded mdate first_treatment, fe(municipality_encoded mdate months_left_encoded female party_encoded) controls(win_margin) hetby(cartel_presence) maxit(20000) autosample

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table A6"

python script "send_email.py", args("`regname'" `h' `m' `s')