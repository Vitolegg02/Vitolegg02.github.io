***Settings and Directory
set maxvar 20000
set more off
set graphics off
cd "C:\Users\vpetukhov\Desktop\Viktor Stata" // change directories if needed
python set exec "C:\Users\vpetukhov\AppData\Local\Programs\Python\Python310\python.exe"
*sysdir set PLUS "D:\2. Documents\5. Other\2. Stata\ado\plus"
capture mkdir "3. Tables"
capture mkdir "4. Figures"
log using "log.smcl"

timer clear 2
timer on 2

***Data Import
use "1. Data\thesis_working_file.dta", clear

***Dofiles
do "2. Dofiles\1_data_cleaning.do"
do "2. Dofiles\2_descriptives.do"
do "2. Dofiles\3_analysis.do"
do "2. Dofiles\4_figures.do"
do "2. Dofiles\5_outputs.do"

timer off 2
timer list 2

local seconds = r(t2)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Thesis Stata Calculations"

python script "send_email.py", args("`regname'" `h' `m' `s')