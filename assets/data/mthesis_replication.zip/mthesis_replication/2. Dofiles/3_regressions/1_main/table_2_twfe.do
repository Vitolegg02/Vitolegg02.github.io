***Table 2 (TWFE)
timer clear 1
timer on 1

**Simple OLS
eststo ols1: reg log_lum treated if trunctuated==1, robust
quietly estadd local mleft "\text{No}", replace
quietly estadd local partyFE "\text{No}", replace
quietly estadd local munFE "\text{No}", replace
quietly estadd local timeFE "\text{No}", replace
quietly estadd local sTrSeas "\text{No}", replace
quietly estadd local errors "\text{Robust}", replace
estadd ysumm, replace

**OLS with Term Controls
eststo ols2: reg log_lum treated i.months_left_encoded if trunctuated==1, robust
quietly estadd local mleft "\text{Yes}", replace
quietly estadd local partyFE "\text{No}", replace
quietly estadd local munFE "\text{No}", replace
quietly estadd local timeFE "\text{No}", replace
quietly estadd local sTrSeas "\text{No}", replace
quietly estadd local errors "\text{Robust}", replace
estadd ysumm, replace

**TWFE with Term Controls
eststo twfe1: reghdfe log_lum treated if trunctuated==1, absorb(mdate municipality_encoded months_left_encoded) vce(cluster municipality_encoded)
quietly estadd local mleft "\text{Yes}", replace
quietly estadd local partyFE "\text{No}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{No}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

**TWFE with Controls
eststo twfe2: reghdfe log_lum treated female win_margin second_term term_length if trunctuated==1, absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)
quietly estadd local mleft "\text{Yes}", replace
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{No}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

**TWFE with Trends
eststo twfe3: reghdfe log_lum treated female win_margin second_term term_length municipality_encoded#c.mdate if trunctuated==1, absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)
quietly estadd local mleft "\text{Yes}", replace
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{Yes}", replace
quietly estadd local sTrSeas "\text{Yes}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table 2 (TWFE)"

python script "send_email.py", args("`regname'" `h' `m' `s')