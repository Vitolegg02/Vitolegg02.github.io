***Descriptives

**Tables and Statistics

collect clear
table treated, statistic(mean log_lum log_pop female win_margin second_term cartel_presence log_wages has_additions has_boni share_boni) statistic(sd log_lum log_pop female win_margin second_term cartel_presence log_wages has_additions has_boni share_boni)
collect label levels result mean "Mean" sd   "SD"
collect layout (var#result) (treated)
collect style cell, nformat(%9.3f)
collect export "3. Tables/1_descriptives.tex", replace
*T-tests
foreach v in log_lum log_pop female win_margin second_term cartel_presence log_wages has_additions has_boni share_boni {
	ttest `v', by(treated)
}