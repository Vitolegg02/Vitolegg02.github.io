**Table 6 (Population, Female, Win Margin)
timer clear 1
timer on 1

*Selection (Female and WM)
preserve
keep if months_to_election==0
sort municipality_encoded year
by municipality_encoded: gen relative_time = _n
xtset municipality_encoded relative_time

*sum female
*sum win_margin

*Gender
*reg female treated, robust
*reg female treated relative_time, robust
eststo fem_reg: reg female treated relative_time i.party_encoded, robust
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{No}", replace
quietly estadd local timeFE "\text{Trend}", replace
quietly estadd local errors "\text{Robust}", replace
estadd ysumm, replace

*Win Margin
*reg win_margin treated, robust
*reg win_margin treated relative_time, robust
eststo wm_reg: reg win_margin treated relative_time female i.party_encoded, robust
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{No}", replace
quietly estadd local timeFE "\text{Trend}", replace
quietly estadd local errors "\text{Robust}", replace
estadd ysumm, replace

*Technical for DiD
by municipality_encoded: egen first_treat_t = min(cond(treated == 1, relative_time, .))

*DiD Gender
*did_imputation female municipality_encoded relative_time first_treat_t, fe(municipality_encoded relative_time) cluster(municipality_encoded) autosample maxit(300)
eststo fem_did: did_imputation female municipality_encoded relative_time first_treat_t, fe(municipality_encoded relative_time party_encoded) cluster(municipality_encoded) autosample maxit(300)
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{FE}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

*DiD Win Margin
*did_imputation win_margin municipality_encoded relative_time first_treat_t, fe(municipality_encoded relative_time) cluster(municipality_encoded) autosample maxit(300)
eststo wm_did: did_imputation win_margin municipality_encoded relative_time first_treat_t, fe(municipality_encoded relative_time party_encoded) controls(female) cluster(municipality_encoded) autosample maxit(300)
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{FE}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

restore


*Log Population
preserve
keep if month==5
xtset municipality_encoded year

*Count Corrupted (for unitcontrols)
gen cor_y = 0
replace cor_y = 1 if missing(win_margin)
replace cor_y = 1 if missing(party_encoded)
gen cuy = 0
replace cuy = 1 if cor_y==1 & treated==0
by municipality_encoded: egen n_cuy = total(cuy)
by municipality_encoded: egen n_try = total(treated)
gen n_uy = 14 - n_try
gen npfy = n_uy-n_cuy

*Transition Sep-Jan: Next Year as Treated
gen ft_year = transition_year+1

*Log Population as Outcome
*sum log_pop if npfy>=2
eststo ln_pop_reg: reghdfe log_pop treated female win_margin last_half_year second_year, absorb(municipality_encoded year party_encoded) vce(cluster municipality_encoded)
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{FE}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace
*With Unit-Specific Trend
eststo ln_pop_did: did_imputation log_pop municipality_encoded year ft_year if npfy>=2, fe(municipality_encoded year last_half_year second_year female party_encoded) controls(win_margin) unitcontrols(year) cluster(municipality_encoded) autosample maxit(300)
quietly estadd local partyFE "\text{Yes}", replace
quietly estadd local munFE "\text{Yes}", replace
quietly estadd local timeFE "\text{FE}", replace
quietly estadd local errors "\text{Mun Cl}", replace
estadd ysumm, replace

restore

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table 6 (Other Outcomes)"

python script "send_email.py", args("`regname'" `h' `m' `s')