***Table A5 (Other DiD Methods)
timer clear 1
timer on 1

**De Chaisemartin and D'Haultfeuille
preserve
**DiD Multiple GT
eststo a5_did1: did_multiplegt_stat log_lum municipality_encoded mdate treated if trunctuated==1, estimator(was) controls(female win_margin m_left_* party_*) cluster(municipality_encoded)
*did_multiplegt_stat log_lum municipality_encoded mdate treated, estimator(was) controls(m_left_*) cluster(municipality_encoded)
*did_multiplegt_stat log_lum municipality_encoded mdate treated if trunctuated==1, estimator(was) controls(m_left_*) cluster(municipality_encoded)

**DiD Multiple Non-Truncated
eststo a5_did2: did_multiplegt_stat log_lum municipality_encoded mdate treated, estimator(was) controls(female win_margin m_left_* party_*) cluster(municipality_encoded)

**DiD Multiple with Dropped States
eststo a5_did3: did_multiplegt_stat log_lum municipality_encoded mdate treated if trunctuated==1 & state_encoded!=30 & state_encoded != 13 & state_encoded != 9, estimator(was) controls(female win_margin m_left_* party_*) cluster(municipality_encoded)

**DiD Multiple with State Trend
eststo a5_did4: did_multiplegt_stat log_lum municipality_encoded mdate treated if trunctuated==1, estimator(was) controls(female win_margin m_left_* party_* state_trend_*) cluster(municipality_encoded)
*did_multiplegt_stat log_lum municipality_encoded mdate treated, estimator(was) controls(female win_margin m_left_* party_* state_trend_*) cluster(municipality_encoded)
*did_multiplegt_stat log_lum municipality_encoded mdate treated, estimator(was) controls(female win_margin m_left_* party_* state_trend_*) cluster(municipality_encoded) weights(population)
*did_multiplegt_stat log_lum municipality_encoded mdate treated if trunctuated==1, estimator(was) controls(female win_margin m_left_* party_* state_trend_*) cluster(municipality_encoded) weights(population)
restore

**Callaway and Sant-Anna
*csdid log_lum i.months_left_encoded female win_margin i.party_encoded if trunctuated==1, ivar(municipality_encoded) time(mdate) gvar(first_treatment) notyet
*csdid log_lum i.months_left_encoded female win_margin i.party_encoded state_trend_* if trunctuated==1, ivar(municipality_encoded) time(mdate) gvar(first_treatment) notyet

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table A5"

python script "send_email.py", args("`regname'" `h' `m' `s')