***Table A1 (Non-Trunctuated TWFE)

timer clear 1
timer on 1

**Simple OLS
eststo a1_ols1: reg log_lum treated, robust

**OLS with Control
eststo a1_ols2: reg log_lum treated i.months_left_encoded, robust
*reg log_lum treated months_to_election, robust
*reg log_lum treated months_to_election if trunctuated==1, robust
*reg log_lum treated months_to_election elections_passed_t, robust
*reg log_lum treated months_to_election elections_passed_t if trunctuated==1, robust
*reg log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t, robust
*reg log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t if trunctuated==1, robust


*Simple TWFE
*reghdfe log_lum treated, absorb(year month municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated if trunctuated==1, absorb(year month municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated if trunctuated==1, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)

**TWFE
eststo a1_twfe1: reghdfe log_lum treated, absorb(mdate municipality_encoded months_left_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated months_to_election elections_passed_t, absorb(year month municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated months_to_election elections_passed_t if trunctuated==1, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t if trunctuated==1, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)

**TWFE with Controls
eststo a1_twfe2: reghdfe log_lum treated female win_margin second_term term_length, absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female if trunctuated==1, absorb(mdate municipality_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female, absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female if trunctuated==1, absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin, absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin if trunctuated==1, absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length, absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length if trunctuated==1, absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)

**TWFE with Weights
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length [aw = population], absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length if trunctuated==1 [aw = population], absorb(mdate municipality_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin second_term term_length [aw = population], absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin i.months_left_encoded second_term term_length if trunctuated==1 [aw = population], absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)

**TWFE with Trends
eststo a1_twfe3: reghdfe log_lum treated female win_margin second_term term_length municipality_encoded#c.mdate, absorb(mdate municipality_encoded months_left_encoded party_encoded) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length state_encoded#c.mdate, absorb(mdate municipality_encoded party_encoded i.state_encoded#month) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length state_encoded#c.mdate if trunctuated==1, absorb(mdate municipality_encoded party_encoded state_encoded#month) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin second_term term_length, absorb(mdate municipality_encoded party_encoded months_left_encoded state_encoded#mdate) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin second_term term_length if trunctuated==1, absorb(mdate municipality_encoded party_encoded months_left_encoded state_encoded#mdate) vce(cluster municipality_encoded)

**Both Weights and Trends
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length state_encoded#c.mdate [aw = population], absorb(mdate municipality_encoded party_encoded state_encoded#month) vce(cluster municipality_encoded)
*reghdfe log_lum treated elections_passed elections_passed_t last_half_year last_half_year_t second_year second_year_t first_years_t female win_margin second_term term_length state_encoded#c.mdate if trunctuated==1 [aw = population], absorb(mdate municipality_encoded party_encoded state_encoded#month) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin second_term term_length [aw = population], absorb(mdate municipality_encoded months_left_encoded party_encoded state_encoded#mdate) vce(cluster municipality_encoded)
*reghdfe log_lum treated female win_margin second_term term_length if trunctuated==1 [aw = population], absorb(mdate municipality_encoded months_left_encoded party_encoded state_encoded#mdate) vce(cluster municipality_encoded)

timer off 1
timer list 1

local seconds = r(t1)
local h = floor(`seconds' / 3600)
local m = floor(mod(`seconds', 3600) / 60)
local s = mod(`seconds', 60)
local regname "Table A1"

python script "send_email.py", args("`regname'" `h' `m' `s')